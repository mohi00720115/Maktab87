package com.example.mohsenakhlaghi_hw9_2

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import java.util.jar.Attributes

class MainActivity : AppCompatActivity() {

    @SuppressLint("ResourceType", "CommitPrefEdits")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //region findViewByIds
        val etFullName = findViewById<EditText>(R.id.etFullName)
        val etUsername = findViewById<EditText>(R.id.etUserName)
        val etEmail = findViewById<EditText>(R.id.etEmail)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val etRePassword = findViewById<EditText>(R.id.etRePassword)
        val radioFemale = findViewById<Button>(R.id.radioFemale)
        val radioMale = findViewById<Button>(R.id.radioMale)
        val btnRegister = findViewById<Button>(R.id.btnRegister)
        val btnShowInfo = findViewById<Button>(R.id.btnShowInfo)
        val btnHideInfo = findViewById<Button>(R.id.btnHideInfo)
        //LinearLayout
        val linearShowInfo = findViewById<View>(R.id.linearShowInfo)
        val tvFullName = findViewById<TextView>(R.id.tvFullName)
        val tvUserName = findViewById<TextView>(R.id.tvUserName)
        val tvEmail = findViewById<TextView>(R.id.tvEmail)
        val tvPassword = findViewById<TextView>(R.id.tvPassword)
        val tvRePassword = findViewById<TextView>(R.id.tvRePassword)
        //endregion
        val sharedPreferences = getSharedPreferences("FULL_NAME", Context.MODE_PRIVATE)

        btnRegister.setOnClickListener {
            val sEdit = sharedPreferences.edit()
            sEdit.putString("FULL_NAME", etFullName.text.toString())
            sEdit.putString("USER_NAME", etUsername.text.toString())
            sEdit.putString("EMAIL", etEmail.text.toString())
            sEdit.putString("PASSWORD", etPassword.text.toString())
            sEdit.putString("RE-PASSWORD", etRePassword.text.toString())
            sEdit.apply()       //Save
            linearShowInfo.visibility = View.INVISIBLE
        }

        btnShowInfo.setOnClickListener {
            tvFullName.text = sharedPreferences.getString("FULL_NAME", null)
            tvUserName.text = sharedPreferences.getString("USER_NAME", null)
            tvEmail.text = sharedPreferences.getString("EMAIL", null)
            tvPassword.text = sharedPreferences.getString("PASSWORD", null)
            tvRePassword.text = sharedPreferences.getString("RE-PASSWORD", null)
            linearShowInfo.visibility = View.VISIBLE

        }

        btnHideInfo.setOnClickListener {
            linearShowInfo.visibility = View.INVISIBLE
        }


    }


}
